// AActor	Type:class USceneComponent*
RootComponent	=	0x230,//(0x8)
// USceneComponent	Type:struct FVector
ComponentVelocity	=	0x2B8,//(0xC)
// USceneComponent	Type:struct FRotator
RelativeRotation	=	0x344,//(0xC)
// USkeletalMeshComponent	Type:class UAnimInstance*
AnimScriptInstance	=	0xCA0,//(0x8)
// UCharacterMovementComponent	Type:float
MaxAcceleration	=	0x318,//(0x4)
// UCharacterMovementComponent	Type:struct FVector
Acceleration	=	0x3B8,//(0xC)
// UCharacterMovementComponent	Type:struct FVector
LastUpdateVelocity	=	0x3E0,//(0xC)
// APawn	Type:class APlayerState*
PlayerState	=	0x438,//(0x8)
// ACharacter	Type:class USkeletalMeshComponent*
Mesh	=	0x520,//(0x8)
// AController	Type:class APawn*
Pawn	=	0x480,//(0x8)
// APlayerController	Type:class APlayerCameraManager*
PlayerCameraManager	=	0x4D0,//(0x8)
// APlayerCameraManager	Type:struct FCameraCacheEntry
CameraCache	=	0x1750,//(0x5D0)
// Class:FMinimalViewInfo	Type:float
FOV	=	0x0,//(0x4)
// Class:FMinimalViewInfo	Type:struct FRotator
Rotation	=	0x598,//(0xC)
// Class:FMinimalViewInfo	Type:struct FVector
Location	=	0x5A4,//(0xC)
// ATslCharacter	Type:float
Health	=	0xF44,//(0x4)
// ATslCharacter	Type:int
SpectatedCount	=	0x120C,//(0x4)
// ATslCharacter	Type:int
LastTeamNum	=	0x1270,//(0x4)
// ATslCharacter	Type:class UWeaponProcessorComponent*
WeaponProcessor	=	0x1290,//(0x8)
// ATslCharacter	Type:float
GroggyHealth	=	0x131C,//(0x4)
// ATslCharacter	Type:struct FString
CharacterName	=	0x1978,//(0x10)
// AItemPackage	Type:TArray<class UItem*>
Items	=	0x580,//(0x10)
// ADroppedItem	Type:class UItem*
Item	=	0x440,//(0x8)
// UWeaponTrajectoryData	Type:struct FWeaponRecoilConfig
RecoilConfig	=	0x48,//(0xD0)
// UWeaponTrajectoryData	Type:struct FWeaponTrajectoryConfig
TrajectoryConfig	=	0x118,//(0x48)
// ATslWeapon_Trajectory	Type:class UWeaponTrajectoryData*
WeaponTrajectoryData	=	0xF00,//(0x8)
// UWeaponProcessorComponent	Type:TArray<class ATslWeapon*>
EquippedWeapons	=	0x2C8,//(0x10)
// UWeaponProcessorComponent	Type:struct FWeaponArmInfo
WeaponArmInfo	=	0x2E8,//(0x5)
// UCrowdFollowingComponent	Type:class UCharacterMovementComponent*
CharacterMovement	=	0x4F0,//(0x8)
